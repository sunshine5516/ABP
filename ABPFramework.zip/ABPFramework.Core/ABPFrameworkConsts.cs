﻿namespace ABPFramework
{
    public class ABPFrameworkConsts
    {
        public const string LocalizationSourceName = "ABPFramework";

        public const bool MultiTenancyEnabled = true;
    }
}