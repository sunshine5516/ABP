﻿ASP.NET Boilerplate - MongoDB
------------------------------

MongoDB implementation for ASP.NET Boilerplate.

IMPORTANT: This project is experimental for now and not tested yet.