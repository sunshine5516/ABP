﻿namespace Abp.MemoryDb.Configuration
{
    public interface IAbpMemoryDbModuleConfiguration
    {
        //TODO: Configuration...
    }
}
