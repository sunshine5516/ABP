﻿using Microsoft.AspNetCore.Mvc;

namespace Abp.AspNetCore.Mvc.ViewComponents
{
    public abstract class AbpViewComponent: ViewComponent
    {
        //TODO: Add base properties and methods
        //TODO: Create view components from dependency injection
    }
}
