﻿namespace Abp.WebApi.Runtime.Caching
{
    public static class ClearCacheSettingNames
    {
        /// <summary>
        /// Abp.WebApi.Runtime.Caching.ClearPassword
        /// </summary>
        public const string Password = "Abp.WebApi.Runtime.Caching.ClearPassword";
    }
}