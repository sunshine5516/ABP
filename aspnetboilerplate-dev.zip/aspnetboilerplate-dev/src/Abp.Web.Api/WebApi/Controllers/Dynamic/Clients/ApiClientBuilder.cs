﻿namespace Abp.WebApi.Controllers.Dynamic.Clients
{
    internal class ApiClientBuilder<TService> : IApiClientBuilder<TService>
    {
        public ApiClientBuilder(string url)
        {
            
        }

        public void Build()
        {
            
        }
    }
}