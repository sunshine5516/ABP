﻿namespace Abp.WebApi.Controllers.Dynamic.Scripting
{
    /// <summary>
    /// 
    /// </summary>
    public enum ProxyScriptType : byte
    {
        JQuery = 0,
        Angular = 1
    }
}
