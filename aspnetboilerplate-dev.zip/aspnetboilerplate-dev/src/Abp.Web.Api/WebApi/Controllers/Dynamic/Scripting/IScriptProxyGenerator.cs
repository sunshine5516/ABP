namespace Abp.WebApi.Controllers.Dynamic.Scripting
{
    internal interface IScriptProxyGenerator
    {
        string Generate();
    }
}