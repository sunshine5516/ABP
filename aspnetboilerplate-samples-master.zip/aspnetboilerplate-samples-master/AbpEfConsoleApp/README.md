This is a simple console application using ASP.NET Boilerplate.
It uses EntityFramework as ORM.

To run the application;

* Check connection string in app.config file and change it if you like.
* Open package manager console and type 'Update-Database' to create database tables and datas.
