﻿namespace AbpWpfDemo
{
    public class AbpWpfDemoConsts
    {
        public const string LocalizationSourceName = "AbpWpfDemo";
    }
}