This is a simple WPF application using ASP.NET Boilerplate. It uses EntityFramework as ORM.

Before running the application;

* Set AbpWpfDemo.UI as startup project.
* Check connection string in app.config file and change it if you like.
* Open package manager console and type 'Update-Database' to create database tables and datas (Don't forget to select AbpWpfDemo.EntityFramework as default project)..
