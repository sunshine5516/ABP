﻿using Abp.Application.Services;

namespace AbpWpfDemo
{
    /// <summary>
    /// Derive your application services from this class.
    /// </summary>
    public abstract class AbpWpfDemoAppServiceBase : ApplicationService
    {

    }
}