﻿using Abp.Application.Services.Dto;

namespace AbpWpfDemo.People.Dto
{
    public class PersonDto : EntityDto
    {
        public string Name { get; set; }
    }
}