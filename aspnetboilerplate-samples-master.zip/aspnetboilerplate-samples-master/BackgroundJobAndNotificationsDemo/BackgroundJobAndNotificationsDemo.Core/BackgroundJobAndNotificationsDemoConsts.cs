﻿namespace BackgroundJobAndNotificationsDemo
{
    public class BackgroundJobAndNotificationsDemoConsts
    {
        public const string LocalizationSourceName = "BackgroundJobAndNotificationsDemo";
    }
}