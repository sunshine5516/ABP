﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Abp.Zero")]
[assembly: InternalsVisibleTo("Abp.ZeroCore")]