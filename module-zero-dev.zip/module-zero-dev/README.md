ASP.NET Boilerplate - Module Zero
===========

AppVeyor: [![Build status](https://ci.appveyor.com/api/projects/status/56e9cadwavg3lj64?svg=true)](https://ci.appveyor.com/project/hikalkan/module-zero)

What is 'module zero'
----------

Module-Zero is the module that implements abstract concepts of ASP.NET Boilerplate framework, also adds some useful stuff for enterprise web applications:

See http://www.aspnetboilerplate.com/Pages/Documents/Zero/Overall for more information.

Sample Projects
-------------------

* https://github.com/aspnetboilerplate/eventcloud
* https://github.com/aspnetboilerplate/questions-answers
