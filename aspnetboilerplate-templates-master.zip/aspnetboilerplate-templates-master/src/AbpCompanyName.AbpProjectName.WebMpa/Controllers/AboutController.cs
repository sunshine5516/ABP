﻿using System.Web.Mvc;

namespace AbpCompanyName.AbpProjectName.WebMpa.Controllers
{
    public class AboutController : AbpProjectNameControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}