namespace AbpCompanyName.AbpProjectName.Web.Controllers
{
    public class LayoutController : AbpProjectNameControllerBase
    {

    }
}