﻿namespace AbpCompanyName.AbpProjectName
{
    public class AbpProjectNameConsts
    {
        public const string LocalizationSourceName = "AbpProjectName";

        public const string ConnectionStringName = "Default";
    }
}